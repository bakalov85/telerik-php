<!doctype html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?= page_title($title); ?></title>
        <link rel="stylesheet" href="assets/site.css" />
    </head>
    <body>
        <header>
            <h1><?= $title ?></h1>
        </header>
        <div id="page">
        